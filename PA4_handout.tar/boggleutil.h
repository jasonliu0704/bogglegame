

#ifndef BOGGLEUTIL_H
#define BOGGLEUTIL_H
//Data structures for lexicon and board should reside in this file.
//All of the operations your data structures support should be declared within your data structures.
#endif
