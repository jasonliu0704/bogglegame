

#include "boggleplayer.h"

void BogglePlayer::buildLexicon(const set<string>& word_list){
}

void BogglePlayer::setBoard(unsigned int rows, unsigned int cols, string** diceArray) {
}

bool BogglePlayer::getAllValidWords(unsigned int minimum_word_length, set<string>* words) {
        return true;
}

bool BogglePlayer::isInLexicon(const string& word_to_check) {
        return true;
}

vector<int> BogglePlayer::isOnBoard(const string& word) {
         vector<int> result;
         return result;
}


void BogglePlayer::getCustomBoard(string** &new_board, unsigned int *rows, unsigned int *cols) {
}

